Blub Chat resource pack for Minecraft Java 26.3

Install this ZIP as a resource pack. To test, run in chat:
/tellraw @s {"text":"Blub: \ue000"}

The private-use character U+E000 renders as Blub when the pack is enabled.
The upcoming server mod will replace :blub: with this character.
To add more emotes later, add textures and font mappings.
